<?php

namespace App\Models\Rooms\Video;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class VideoRoomMember extends Model
{
    use HasFactory;
}
