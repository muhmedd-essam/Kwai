<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\SuperAdmin;
use App\Models\User;
use App\Models\VipUser;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class VipUserController extends Controller
{
    public function store($userId ,Request $request){
        $admin = SuperAdmin::find(auth()->user()->id);
        $vipStatus = $request->input('vip');
        $user= User::findOrFail($userId);
        if(!$admin){
            // if ($userId == auth()->user()->id){
            //     if ($vipStatus !== null) {
            //         $user->vip = $vipStatus;
            //         $user->save();
            //     }
            //     return response()->json(['message' => 'تم الشراء بنجاح'], 200);
            // }
            return response()->json(['message' => 'غير مصرح لك'], 404);
        }

        if ($vipStatus !== null) {
            $user->vip = $vipStatus;
            $user->save();
        }
        return response()->json(['message' => 'تم الشراء بنجاح']);

    }

}
