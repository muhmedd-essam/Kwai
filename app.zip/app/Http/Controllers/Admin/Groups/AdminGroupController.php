<?php

namespace App\Http\Controllers\Admin\Groups;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class AdminGroupController extends Controller
{
    public function index()
    {
        //
    }

    public function show()
    {

    }

    public function getGroupMembers()
    {
        //
    }

    public function update()
    {
        //
    }

    public function destroy()
    {
        //
    }

}
